function defineCheckMinPortSpaces

% Create ModelAdvisor.Check object and set properties.
rec = ModelAdvisor.Check('com.mathworks.sample.minPortSpace');
rec.Title = 'Check if spaces between ports are too small';
rec.TitleTips = 'Check spaces between ports';
rec.setCallbackFcn(@DetailStyleCallback,'None','DetailStyle');

% publish check.
mdladvRoot = ModelAdvisor.Root;
mdladvRoot.publish(rec, 'MyChecks'); 

end

% -----------------------------
% This callback function uses the DetailStyle CallbackStyle type. 
% -----------------------------
function DetailStyleCallback(system, CheckObj)
% get Model Advisor object
mdladvObj = Simulink.ModelAdvisor.getModelAdvisor(system); 

% Find all blocks
allBlks = find_system(system,'findAll','on','Type','block');
violationBlks = [];
for ii=1:length(allBlks)
    thisBlk = allBlks(ii);
    portHandles = get_param(thisBlk,'PortHandles');
    inportHandles = portHandles.Inport;
    outportHandles = portHandles.Outport;
    if(length(inportHandles) <= 1 && length(outportHandles) <= 1)
        %skip blocks with no more than 1 IO port
        continue;
    end
    %Get input port handles
    inportPositions = get(inportHandles,'Position');
    if(iscell(inportPositions))
        inportPositions = cell2mat(inportPositions);
    end
    %Calculate spaces between input ports
    inportSpaces = diff(sort(inportPositions,1),1,1);
    %Get output port handles
    outportPositions = get(outportHandles,'Position');
    if(iscell(outportPositions))
        outportPositions = cell2mat(outportPositions);
    end
    %Calculate spaces between output ports
    outportSpaces = diff(sort(outportPositions,1),1,1);
    %Get minimum space
    minSpace = min(vertcat(inportSpaces(:,2),outportSpaces(:,2)));
    if(minSpace > 10)
        continue;
    end
    violationBlks = [violationBlks,get_param(thisBlk,'Handle')];
end
if isempty(violationBlks)
    ElementResults = ModelAdvisor.ResultDetail;
    ElementResults.IsInformer = true;
    ElementResults.Description = 'Identify blocks whose ports have spaces no wider than 10 pixels.';
    ElementResults.Status = 'All port spaces are above 10 pixels.';
    mdladvObj.setCheckResultStatus(true);
else
    for i=1:numel(violationBlks)
	 ElementResults(1,i) = ModelAdvisor.ResultDetail;
    end
    for i=1:numel(ElementResults)
        ModelAdvisor.ResultDetail.setData(ElementResults(i), 'SID',violationBlks(i));
        ElementResults(i).Description = 'Identify blocks whose port spaces are less than 10 pixels.';
        ElementResults(i).Status = 'The following blocks have port spaces less than 10 pixels:';
        ElementResults(i).RecAction =  'Expand the block.';
    end
    mdladvObj.setCheckResultStatus(false);
    mdladvObj.setActionEnable(true);
end
CheckObj.setResultDetails(ElementResults);
end